(function($){
	$(document).ready( function(){
		var $save_message = $("#epanel-ajax-saving"),
			$save_message_spinner = $save_message.children("img"),
			$save_message_description = $save_message.children("span");

	});
})(jQuery)